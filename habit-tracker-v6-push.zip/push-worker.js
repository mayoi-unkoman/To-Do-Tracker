// =============================================
// Cloudflare Worker — Push通知サーバー
// =============================================
// 環境変数（Cloudflareダッシュボードで設定）:
//   VAPID_PUBLIC_KEY  - 公開鍵（base64url）
//   VAPID_PRIVATE_KEY - 秘密鍵（base64url）
//   VAPID_SUBJECT     - mailto:your-email@example.com
//
// KV Namespace:
//   PUSH_SUBS - Push購読データ保存用
//
// Cron Trigger:
//   設定例: 0 16 * * *  (UTC 16:00 = JST 1:00)
//          0 17 * * *  (UTC 17:00 = JST 2:00)
//          0 18 * * *  (UTC 18:00 = JST 3:00)
// =============================================

// ---- CORS設定 ----
const CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
};

// ---- メインハンドラ ----
export default {
    // HTTPリクエスト処理
    async fetch(request, env) {
        // CORS preflight
        if (request.method === 'OPTIONS') {
            return new Response(null, { headers: CORS_HEADERS });
        }

        const url = new URL(request.url);

        // 購読登録
        if (url.pathname === '/subscribe' && request.method === 'POST') {
            return handleSubscribe(request, env);
        }

        // 購読解除
        if (url.pathname === '/unsubscribe' && request.method === 'POST') {
            return handleUnsubscribe(request, env);
        }

        // 手動Push送信（テスト用）
        if (url.pathname === '/test-push' && request.method === 'POST') {
            return handleTestPush(env);
        }

        // ヘルスチェック
        if (url.pathname === '/' || url.pathname === '/health') {
            return jsonResponse({ status: 'ok', message: 'Push notification server is running' });
        }

        return jsonResponse({ error: 'Not Found' }, 404);
    },

    // Cron Trigger処理（定期実行）
    async scheduled(event, env) {
        await sendPushToAll(env, '習慣トラッカー', '📋 タスクを確認してください');
    },
};

// ---- 購読登録 ----
async function handleSubscribe(request, env) {
    try {
        const subscription = await request.json();
        if (!subscription || !subscription.endpoint) {
            return jsonResponse({ error: 'Invalid subscription' }, 400);
        }

        // endpointをキーとして保存
        const key = btoa(subscription.endpoint).replace(/[^a-zA-Z0-9]/g, '');
        await env.PUSH_SUBS.put(key, JSON.stringify(subscription));

        return jsonResponse({ success: true });
    } catch (e) {
        return jsonResponse({ error: e.message }, 500);
    }
}

// ---- 購読解除 ----
async function handleUnsubscribe(request, env) {
    try {
        const { endpoint } = await request.json();
        if (!endpoint) {
            return jsonResponse({ error: 'Missing endpoint' }, 400);
        }

        const key = btoa(endpoint).replace(/[^a-zA-Z0-9]/g, '');
        await env.PUSH_SUBS.delete(key);

        return jsonResponse({ success: true });
    } catch (e) {
        return jsonResponse({ error: e.message }, 500);
    }
}

// ---- テスト用Push送信 ----
async function handleTestPush(env) {
    const result = await sendPushToAll(env, '習慣トラッカー', '🔔 テスト通知です！');
    return jsonResponse(result);
}

// ---- 全購読者にPush送信 ----
async function sendPushToAll(env, title, body) {
    const list = await env.PUSH_SUBS.list();
    let sent = 0, failed = 0, cleaned = 0;

    for (const key of list.keys) {
        const subJson = await env.PUSH_SUBS.get(key.name);
        if (!subJson) continue;

        try {
            const subscription = JSON.parse(subJson);
            const payload = JSON.stringify({ title, body });

            const success = await sendWebPush(
                subscription,
                payload,
                env.VAPID_PUBLIC_KEY,
                env.VAPID_PRIVATE_KEY,
                env.VAPID_SUBJECT
            );

            if (success) {
                sent++;
            } else {
                // 410 Gone = 購読が無効 → 削除
                await env.PUSH_SUBS.delete(key.name);
                cleaned++;
            }
        } catch (e) {
            failed++;
        }
    }

    return { sent, failed, cleaned, total: list.keys.length };
}

// ---- Web Push送信（RFC 8291/8188準拠） ----
async function sendWebPush(subscription, payload, vapidPublicKey, vapidPrivateKey, vapidSubject) {
    const endpoint = subscription.endpoint;
    const p256dh = subscription.keys.p256dh;
    const auth = subscription.keys.auth;

    // VAPID JWT生成
    const audience = new URL(endpoint).origin;
    const jwt = await createVapidJwt(audience, vapidSubject, vapidPrivateKey);
    const vapidPubKeyForHeader = vapidPublicKey;

    // ペイロード暗号化
    const encrypted = await encryptPayload(p256dh, auth, payload);

    // Push送信
    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Authorization': `vapid t=${jwt},k=${vapidPubKeyForHeader}`,
            'Content-Encoding': 'aes128gcm',
            'Content-Type': 'application/octet-stream',
            'TTL': '86400',
            'Urgency': 'high',
        },
        body: encrypted,
    });

    return response.status >= 200 && response.status < 300;
}

// ---- VAPID JWT生成 ----
async function createVapidJwt(audience, subject, privateKeyB64) {
    const header = { typ: 'JWT', alg: 'ES256' };
    const now = Math.floor(Date.now() / 1000);
    const claims = {
        aud: audience,
        exp: now + 86400,
        sub: subject,
    };

    const headerB64 = b64urlEncode(JSON.stringify(header));
    const claimsB64 = b64urlEncode(JSON.stringify(claims));
    const unsignedToken = `${headerB64}.${claimsB64}`;

    // 秘密鍵をインポート
    const privateKeyBytes = b64urlDecode(privateKeyB64);
    const key = await crypto.subtle.importKey(
        'jwk',
        {
            kty: 'EC',
            crv: 'P-256',
            d: privateKeyB64,
            x: 'dummy', // Will be replaced
            y: 'dummy', // Will be replaced
        },
        { name: 'ECDSA', namedCurve: 'P-256' },
        false,
        ['sign']
    ).catch(async () => {
        // Fallback: import raw private key
        const jwk = await privateKeyToJwk(privateKeyBytes);
        return crypto.subtle.importKey(
            'jwk', jwk,
            { name: 'ECDSA', namedCurve: 'P-256' },
            false, ['sign']
        );
    });

    const signature = await crypto.subtle.sign(
        { name: 'ECDSA', hash: 'SHA-256' },
        key,
        new TextEncoder().encode(unsignedToken)
    );

    // DER to raw signature
    const sigBytes = new Uint8Array(signature);
    const rawSig = derToRaw(sigBytes);

    return `${unsignedToken}.${b64urlEncodeBytes(rawSig)}`;
}

// ---- ペイロード暗号化（aes128gcm） ----
async function encryptPayload(p256dhB64, authB64, payload) {
    const clientPublicKey = b64urlDecode(p256dhB64);
    const authSecret = b64urlDecode(authB64);
    const payloadBytes = new TextEncoder().encode(payload);

    // サーバー一時鍵を生成
    const serverKeys = await crypto.subtle.generateKey(
        { name: 'ECDH', namedCurve: 'P-256' },
        true,
        ['deriveBits']
    );

    const serverPublicKey = await crypto.subtle.exportKey('raw', serverKeys.publicKey);
    const serverPublicKeyBytes = new Uint8Array(serverPublicKey);

    // クライアント公開鍵をインポート
    const clientKey = await crypto.subtle.importKey(
        'raw', clientPublicKey,
        { name: 'ECDH', namedCurve: 'P-256' },
        false, []
    );

    // ECDH共有秘密を導出
    const sharedSecret = await crypto.subtle.deriveBits(
        { name: 'ECDH', public: clientKey },
        serverKeys.privateKey,
        256
    );

    // IKMを導出
    const authInfo = createInfo('WebPush: info\0', clientPublicKey, serverPublicKeyBytes);
    const ikm = await hkdfDerive(authSecret, new Uint8Array(sharedSecret), authInfo, 32);

    // salt (16バイトランダム)
    const salt = crypto.getRandomValues(new Uint8Array(16));

    // PRK
    const prk = await hkdfExtract(salt, ikm);

    // CEK (Content Encryption Key)
    const cekInfo = createCekInfo('Content-Encoding: aes128gcm\0');
    const cek = await hkdfExpand(prk, cekInfo, 16);

    // Nonce
    const nonceInfo = createCekInfo('Content-Encoding: nonce\0');
    const nonce = await hkdfExpand(prk, nonceInfo, 12);

    // パディング
    const paddedPayload = new Uint8Array(payloadBytes.length + 2);
    paddedPayload.set(payloadBytes);
    paddedPayload[payloadBytes.length] = 2; // delimiter
    paddedPayload[payloadBytes.length + 1] = 0;

    // AES-GCM暗号化
    const cekKey = await crypto.subtle.importKey(
        'raw', cek, { name: 'AES-GCM' }, false, ['encrypt']
    );

    const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: nonce },
        cekKey,
        paddedPayload
    );

    // aes128gcm ヘッダー構築
    const recordSize = new Uint8Array(4);
    new DataView(recordSize.buffer).setUint32(0, paddedPayload.length + 16 + 1); // +16 for tag, +1

    const header = new Uint8Array(
        salt.length + 4 + 1 + serverPublicKeyBytes.length
    );
    let offset = 0;
    header.set(salt, offset); offset += salt.length;
    header.set(recordSize, offset); offset += 4;
    header[offset] = serverPublicKeyBytes.length; offset += 1;
    header.set(serverPublicKeyBytes, offset);

    // 結合
    const result = new Uint8Array(header.length + encrypted.byteLength);
    result.set(header);
    result.set(new Uint8Array(encrypted), header.length);

    return result;
}

// ---- ヘルパー関数 ----
function b64urlEncode(str) {
    return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlEncodeBytes(bytes) {
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlDecode(str) {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    return Uint8Array.from(atob(str), c => c.charCodeAt(0));
}

function createInfo(type, clientPublicKey, serverPublicKey) {
    const typeBytes = new TextEncoder().encode(type);
    const info = new Uint8Array(typeBytes.length + clientPublicKey.length + serverPublicKey.length);
    info.set(typeBytes);
    info.set(new Uint8Array(clientPublicKey), typeBytes.length);
    info.set(new Uint8Array(serverPublicKey), typeBytes.length + clientPublicKey.length);
    return info;
}

function createCekInfo(type) {
    return new TextEncoder().encode(type);
}

async function hkdfExtract(salt, ikm) {
    const key = await crypto.subtle.importKey('raw', salt, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    return new Uint8Array(await crypto.subtle.sign('HMAC', key, ikm));
}

async function hkdfExpand(prk, info, length) {
    const key = await crypto.subtle.importKey('raw', prk, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const infoWithCounter = new Uint8Array(info.length + 1);
    infoWithCounter.set(info);
    infoWithCounter[info.length] = 1;
    const result = new Uint8Array(await crypto.subtle.sign('HMAC', key, infoWithCounter));
    return result.slice(0, length);
}

async function hkdfDerive(salt, ikm, info, length) {
    const prk = await hkdfExtract(salt, ikm);
    return hkdfExpand(prk, info, length);
}

function derToRaw(der) {
    // ECDSA署名をDER形式からraw(r || s)に変換
    if (der.length === 64) return der; // Already raw
    const rLen = der[3];
    const r = der.slice(4, 4 + rLen);
    const sLen = der[5 + rLen];
    const s = der.slice(6 + rLen, 6 + rLen + sLen);
    const raw = new Uint8Array(64);
    raw.set(r.length > 32 ? r.slice(r.length - 32) : r, 32 - Math.min(r.length, 32));
    raw.set(s.length > 32 ? s.slice(s.length - 32) : s, 64 - Math.min(s.length, 32));
    return raw;
}

async function privateKeyToJwk(privateKeyBytes) {
    // Generate a temporary key pair to get x, y coordinates
    const tempKey = await crypto.subtle.generateKey(
        { name: 'ECDSA', namedCurve: 'P-256' },
        true, ['sign', 'verify']
    );
    const tempJwk = await crypto.subtle.exportKey('jwk', tempKey.privateKey);
    // Replace d with our private key
    tempJwk.d = b64urlEncodeBytes(privateKeyBytes);
    return tempJwk;
}

function jsonResponse(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
    });
}
